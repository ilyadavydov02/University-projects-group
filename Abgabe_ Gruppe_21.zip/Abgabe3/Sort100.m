function Sorter = Sort100()
% This function compares the GUI grid ('Targetgrid') to the scanned 'Colourgrid' and sorts
% until both are equal. It overwrites 'Colorgrid' after cube on base is scanned and returns it to it's home.
% It needs the functions farbe.m, winkeln.m, winkeln2.m, Cubegrid2.m and Scan2.m in order to work properly.
% The actual activation file is command.m

 global vRob % Has to be global so command.m and Scan2.m can pass on robot
 global Cubecoordinates; % Calls Global Varibale where cube coordinates are located.
 Cubecoordinates  = zeros(9,3); % Creates empty list for cube coordinates.
 Cubegrid2; % Fills empty global list with coordinates.
 global Colorgrid;
 global Colormess;
 global Targetgrid;

 i2 = 1;
 i3 = 1;
 i4 = 1;

  if Colorgrid == Targetgrid
   
      disp('Package already in Order.')  % When the scanned grid is identical with the entered grid.
  
  else
      %% Cubefinding%%
     for i = 1:9;
      if Targetgrid(i4, i2) == Colorgrid(i4, i2) % If parameter of GUI matrix (colour) and parameter of scanned matrix identical, Program skips the cube. 
          i= +i;
          i2 = i2+1;
          i3 = i3+1;
          if i2 == 4; % For Matrix; only goes to three
            i2 =  1;
            i4 = i4 +1;
          end    

      else    
           %% Get Cube%%
           [d, a, b, g] = winkeln(Cubecoordinates(i,1), Cubecoordinates(i,2)); % Gets coordinates from different function, where the coordinates of every cube is saved (x and y).  
           vRob.moveAngles([1, 2, 3, 4, 5], [d, a, b, g, d], -1); % Fills in calculated angles.
           vRob.waitFor
           vRob.closeHand
           vRob.waitFor
           vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1); % Zero position. Robot needs it otherwise cause colossion errors.
           vRob.waitFor
           [d, a, b, g] = winkeln(170, 0); % Gets coordinates from different function, where the coordinates of every cube is saved (x and y).  
           vRob.moveAngles([1, 2, 3, 4, 5], [d, a, b, g, d], -1);% move to base where cube is going to be turned.
           vRob.waitFor
           vRob.openHand
           vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1);
           vRob.waitFor
           %% First Turn (Y-Axis) %%
           while Targetgrid(i4,i2) ~= Colorgrid (i4,i2) % While loop, because it evens out potential measuring errors. 
            vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1); % zero position
            vRob.waitFor   
            vRob.moveAngles([1 2 3 4 5],[0 39.55 95.57 94.87 0],-1); %base
            vRob.waitFor
            vRob.closeHand
            vRob.waitFor
            vRob.moveAngles([1 2 3 4 5],[0 -14 126 67.87 0],-1); % Middle for not causing collision errors.
            vRob.waitFor
            vRob.moveAngles([1 2 3 4 5],[0 -25.3 162.7 2.5 0],-1); % 90 degree turn on Y-Axis.
            vRob.waitFor
            vRob.openHand
            vRob.waitFor
            vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1);
            vRob.waitFor
            %% Colorscan %%
            vRob.moveAngles([1, 2, 3, 4, 5], [0, 11.16, 159.10, -80.26, 0], -1); % Fills in calculated angles.
            vRob.waitFor() % Robot must stand still to scan.
            ColorVector = vRob.getSensorColor(); % Scans colour and saves it as Vector(R, B ,G).
            R = ColorVector(1,1); %
            G = ColorVector(1,2); % Splits vector in 3 Parts, so farbe.m can use it.
            B = ColorVector(1,3); %
            farbe(R, G, B);
            Colorgrid(i4, i2) = Colormess;
            vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1);
            vRob.waitFor
            if Targetgrid(i4, i2) == Colorgrid(i4, i2); % When Cube is found, program resumes
                break;
            end
  
            %% Second Turn %%
            vRob.moveAngles([1 2 3 4 5],[0 -0.6 132.7 47.92 0],-1);
            vRob.waitFor
            vRob.moveAngles([5],[90],-1); % make 90 degree turn around the Z-Axis.
            vRob.waitFor
            vRob.closeHand
            vRob.waitFor
            vRob.moveAngles([1 2 3 4 5],[0 -0.6 132.7 47.92 0],-1);
            vRob.waitFor
            vRob.openHand
            vRob.waitFor
            vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1);
            vRob.waitFor

           end
          %% Return Cube %%
           vRob.moveAngles([1 2 3 4 5],[0 -25.3 162.7 2.5 0],-1); % Still turn
           vRob.waitFor
           vRob.closeHand
           vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1);
           vRob.waitFor
           [d, a, b, g] = winkeln(Cubecoordinates(i,1), Cubecoordinates(i,2)); %Different Formula 
           vRob.moveAngles([1, 2, 3, 4, 5], [d, a, b, g, d], -1);
           vRob.waitFor
           vRob.openHand
           vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1);
           vRob.waitFor
           
           i2 = i2+1;
           i3 = i3+1;
           if i2 == 4; % For Matrix; only goes to three
             i2 =  1;
             i4 = i4 +1;
           end    
      %else

      end
     end
  disp(Colorgrid)
  end

  
end