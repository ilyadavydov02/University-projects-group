function[d, a1, b1, g2]=winkeln2(x, y)
% This is the formula to calculate where the scanner has to be and puts out the angles of Base (d), Shoulder (a1), upperarm (b1) and lowerarm (g2).
s = sqrt(x^2+y^2);
s1 = s - 101;
c = sqrt(s1^2 + 51.9^2);
b = 218;
a = 166;
y1 = acosd((b^2-a^2-c^2)/(-2*a*c));
y2 = acosd((s1^2-c^2-52^2)/(-2*52*c));
a1 = 180 - y1 - y2;
y5 = acosd((c^2-a^2-b^2)/(-2*a*b));
b1 = 180 - y5;
y3 = acosd((52^2-c^2-s1^2)/(-2*c*s1));
y4 = acosd((a^2-b^2-c^2)/(-2*b*c));
g = y3 + y4;
g2 = -g;
d = atand(y/x);
%vRob.moveAngles([1, 2, 3, 4, 5], [d, a1, b1, g2, 0], -1) call