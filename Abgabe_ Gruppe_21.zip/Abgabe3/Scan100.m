function Scanner2 = Scan100()
% This function visits every cube on the grid and scanns it.
% The output is a 3x3 matrix with the values of the colours: red=1,green=2, blue=3.
% It needs the following functions to operate correctly: 
% "Cubegrid2.m" for the cube coordinates,
% "winkeln2.m" for the calculation of the angles of the robo arms and
% "farbe.m" for determing the colour of the cubes.
%vRob = VirtualRobot('random'); 
 global vRob 
 vRob = VirtualRobot('random')
 global Cubecoordinates; % Calls Global Varibale where cube coordinates are located.
 Cubecoordinates  = zeros(9,3); % Creates empty list for cube coordinates.
 Cubegrid2; % Fills empty global list with coordinates.
 global Colorgrid; 
 Colorgrid = zeros(3,3); % Empty 3x3 matrix for colours.
 global Colormess; % Is later used by farbe.m to fill colour matrix.
 ColorVector = zeros(1,3); %Empty Vector for scanned colours.
 
 iii =1; % Can theoreticly rise until infinity (but goes to 10). For cube Coordinates (1,1 / 1,2 - 9,1/ 9,2).
 ii = 1; % Goes to 3 once. For Colorgrid rows. (1-3).
 i= 1; % Goes to 3 three times. For Colorgrid columns. (1-3).

 for ii = 1:3 % Outer for loop (1*3).
  for i = 1:3 % Inner for loop (3*3).
   [d, a1, b1, g2] = winkeln2(Cubecoordinates(iii,1), Cubecoordinates(iii,2)); % Gets coordinates by using formula from seperate function (winkeln2.m) and the coordinates of the cubes from Cubegrid2.m.
   vRob.moveAngles([1, 2, 3, 4, 5], [d, a1, b1, g2, 0], -1); % Fills in calculated angles.
   vRob.waitFor() % Robot must stand still to scan.
   ColorVector = vRob.getSensorColor(); % Scans colour and saves it as Vector(R, B ,G).
   R = ColorVector(1,1); %
   G = ColorVector(1,2); % Splits vector in 3 Parts, so farbe.m can use it.
   B = ColorVector(1,3); %
   farbe(R, G, B); %Calls farbe.m to determin colour.
   Colorgrid(ii, i) = Colormess; % Saves the value from farbe.m (red = 1, green = 2, blue = 3) in a 3x 3 matrix)
   iii = iii+1;
  end
 end 
 disp(Colorgrid);
 vRob.moveAngles([1, 2, 3, 4, 5], [0, -70, 150, 0, 0], -1);
 vRob.waitFor





 
end