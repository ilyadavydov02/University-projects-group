function farbe = sensorinterpretation(R,G,B)
%You have to insert the Values yourself into RGB in "Run" under "Run: type
%code to run".
%Clear all had to be deleted, because it empties RGB, before the programm
%can use it

global Colormess

if R < 0
disp('Die Zahl darf nicht kleiner als 0 sein. Versuchen Sie es erneut mit einem Vektor, in dem alle Werte >= 0 sind.')
return
end
if G < 0
disp('Die Zahl darf nicht kleiner als 0 sein. Versuchen Sie es erneut mit einem Vektor, in dem alle Werte >= 0 sind.')
return
end
if B < 0
disp('Die Zahl darf nicht kleiner als 0 sein. Versuchen Sie es erneut mit einem Vektor, in dem alle Werte >= 0 sind.')
return
end

%Nur für den Fall, dass einer der Werte des Vektors 0 ist, 
%ersetzen wir ihn durch eine Zahl nahe Null (0.1)
%Dies ist notwendig, um nicht gegen die Gesetze der Mathematik bei der Teilung zu brechen. 
%Da nicht durch Null geteilt werden kann.
if R == 0 
R = 0.1;
end
if G == 0 
G = 0.1;
end
if B == 0 
B = 0.1;
end

%Jetzt teilen wir die Werte durcheinander und erhalten die Zahlen, 
%mit denen wir die Farbe bestimmen können.
x = R / G;
y = G / B;
z = B / R;

%Wir geben zur Vereinfachung die Variablen xx, yy, zz  ein. 
%Mit ihrer Hilfe werden wir ermitteln, ob eine der Drei Variablen im
%Toleranzbereich von schwarz (0.8 bis 1.2) liegt.
if ((x >= 0.8) && (x <= 1.2))
   xx = 1;
else 
   xx = 0;
end
if ((y >= 0.8) && (y <= 1.2))
   yy = 1;
else 
   yy = 0;
end
if ((z >= 0.8) && (z <= 1.2))
   zz = 1;
else 
   zz = 0;
end

%Wenn diese Zahlen zwischen 0.8 und 1.2 liegt, dann kann die Farbe nur schwarz sein. 
%Der Einfachheit halber geben wir die Variable n ein, um dies nicht jedes Mal neu zu schreiben.
if (xx == 1) || (yy == 1) || (zz == 1)
    n = 1;
else 
    n = 0;
end

%Jetzt vergleichen wir einfach die Werte.
if n == 0
if R > G && R > B 
   farbe = 'Red';%Gives VAlue for Colorgrid
   Colormess = 1;
elseif G > B && G > R 
   farbe = 'Green';
   Colormess = 2;
elseif B > G && B > R 
   farbe = 'Blue';
   Colormess = 3;
end
elseif n == 1
if (xx == 1) && (yy == 0) && (zz == 0)
if R > B 
    farbe = 'Black';
elseif B > R
    farbe = 'Blue';
    Colormess = 3;
end
elseif (xx == 0) && (yy == 1) && (zz == 0)
if G > R 
    farbe = 'Black';
elseif R > G
    farbe = 'Red';
    Colormess = 1;
end
elseif (xx == 0) && (yy == 0) && (zz == 1)
if B > G 
    farbe = 'Black';
elseif G > B
    farbe = 'Green';
    Colormess = 2;
end
elseif (xx == 1) && (yy == 1) && (zz == 1)
  farbe = 'Black';
end  
end
end



