function Cubegrid

global Cubecoordinates

global cube1 
Cubecoordinates(1,1) = (380); %Coordinates Middle + 10. (Otherwise doesen't recognize Cube)
Cubecoordinates(1,2) = (60);
Cubecoordinates(1,3) = (0); % Z is empty can be removed.

global cube2 
Cubecoordinates(2,1) = (380);
Cubecoordinates(2,2) = (0);
Cubecoordinates(2,3) = (0);

global cube3 
Cubecoordinates(3,1) = (380);
Cubecoordinates(3,2) = (-60);
Cubecoordinates(3,3) = (0);

global cube4
Cubecoordinates(4,1) = (320);
Cubecoordinates(4,2) = (60);
Cubecoordinates(4,3) = (0);

global cube5 
Cubecoordinates(5,1) = (320);
Cubecoordinates(5,2) = (0);
Cubecoordinates(5,3) = (0);

global cube6 
Cubecoordinates(6,1) = (320);
Cubecoordinates(6,2) = (-60);
Cubecoordinates(6,3) = (0);

global cube7
Cubecoordinates(7,1) = (260);
Cubecoordinates(7,2) = (60);
Cubecoordinates(7,3) = (0);

global cube8
Cubecoordinates(8,1) = (260);
Cubecoordinates(8,2) = (0);
Cubecoordinates(8,3) = (0);

global cube9
Cubecoordinates(9,1) = (260);
Cubecoordinates(9,2) = (-60);
Cubecoordinates(9,3) = (0);

end