function[d, a, b, g] = winkeln(x, y)
%This calculates, where the midlle of the cube is and puts out the angles of Base (d), Shoulder (a), upperarm (b) and lowerarm (g). 
x = x-10;
x3=acosd((166^2-218^2-(x^2+y^2+19.9^2))/(-2*(218*sqrt(x^2+y^2+19.9^2))));
x2=acosd((19.9^2-(x^2+y^2)-(x^2+y^2+19.9^2))/(-2*sqrt(x^2+y^2)*sqrt(x^2+y^2+19.9^2)));
x1 = x3 - x2;
g = 90-x1;
b = 180-acosd((x^2+y^2+19.9^2-166^2-218^2)/(-2*166*218));
b1 = 180-b;
a = 90 - (180 - x1 - b1);
d=atand(y/x);

